part of 'list_bloc.dart';

 class ListEvent extends Equatable {
  @override
  List<Object?> get props => throw UnimplementedError();

}
 class ListFetched extends ListEvent{}