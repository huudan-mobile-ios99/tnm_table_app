part of 'stream_bloc.dart';

 class StreamMEvent extends Equatable {
  @override
  List<Object?> get props => throw UnimplementedError();

}
 class StreamFeteched extends StreamMEvent{}