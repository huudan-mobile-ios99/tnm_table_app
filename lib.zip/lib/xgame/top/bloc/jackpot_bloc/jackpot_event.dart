part of 'jackpot_bloc.dart';


 class JackpotEvent extends Equatable {
  @override
  List<Object?> get props => throw UnimplementedError();

}
 class JackpotFetched extends JackpotEvent{}