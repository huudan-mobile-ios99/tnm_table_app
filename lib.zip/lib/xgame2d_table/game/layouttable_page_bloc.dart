import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tournament_client/utils/mycolors.dart';
import 'package:tournament_client/utils/mystring.dart';
import 'package:tournament_client/widget/text.dart';
import 'package:tournament_client/xgame2d_table/chart/bloc/chartBloc.dart';
import 'package:tournament_client/xgame2d_table/view/chartStreamNew.dart';

class LayoutTablePageBlocPage extends StatelessWidget {
  const LayoutTablePageBlocPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;
    final heightItem = height/3.75;
    final widthItem = width/5.225;



   return BlocProvider(
      create:  (context) => ChartStreamBloc(),
      child: BlocBuilder<ChartStreamBloc, ChartStreamState>(
         builder: (context, state)  {
         final List<String> memberNumber = state.members.isNotEmpty ? state.members : List.filled(5, '');
         final List<Object> inputNumbers = state.inputNumbers.isNotEmpty ? state.inputNumbers : List.filled(5, '');
        return
         Stack(
          children: [
            Positioned(
              top: heightItem/3.15,
              left: width / 18,
              child: layoutChildItem(
              index: 0,
              number:memberNumber[4],
              height: heightItem,
              width: widthItem,
              ),
            ), //#tag1


            Positioned(
              top: heightItem * 1.525,
              left: width / 6.65,
              child: layoutChildItem(
              index: 1,
              number:memberNumber[3],
              height: heightItem,
              width: widthItem,
              ),
            ), //#2

            Positioned(
              top: heightItem*2.285,
              left:width/2-widthItem/2,
              child:
                layoutChildItem(
                    index: 2,
                    number:memberNumber[2],
                    height: heightItem,
                    width: widthItem,
                  ),

            ), //#3

            Positioned(
              top: heightItem * 1.525,
              left: width - widthItem - width / 6.65,
              child: layoutChildItem(
              index: 3,
              number:memberNumber[1],
              height: heightItem,
              width: widthItem,

              ),
            ), //#4


            Positioned(
              top: heightItem/3.15,
              left: width - widthItem - width / 18,
              child: layoutChildItem(
              index: 4,
              number:memberNumber[0],
              height: heightItem,
              width: widthItem,
              ),
            ), //#5

            // 2D Game Page
            // const ChartStreamPage(),
            const ChartStreamPageNew(),
            ]);
        },),);
  }
}

Widget layoutChildItem({required int index,
  required String number,required double width,required double height, }){
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisSize: MainAxisSize.min,
    children: [
      // number.isEmpty || number =='' || number=='...' ? Container():Container(
      //   padding: const EdgeInsets.symmetric(horizontal:MyString.padding04,vertical: 0),
      //   decoration:BoxDecoration(
      //     color: MyColor.white,
      //     border: Border.all(color:MyColor.yellow3,width: MyString.padding02),
      //    borderRadius: BorderRadius.only(
      //     topLeft: Radius.circular(MyString.padding10),
      //     topRight: Radius.circular(MyString.padding08),
      //   ),
      //   ),
      //   child: textcustomColor(text:'No. $index',color:MyColor.black_absolute,size:MyString.padding12,isBold: true),),
      Container(
                  width: width,
                  height:height,
                  decoration: const BoxDecoration(
                    // color:MyColor.appBar,
                  image: DecorationImage(
                  image: AssetImage('assets/bg_round.png'),
                  fit: BoxFit.contain,
                  ),
                  ),
                ),
      const SizedBox(height:MyString.padding04),
      number.isEmpty || number =='' || number=='...' ? Container(): Container(
        padding: const EdgeInsets.symmetric(horizontal:MyString.padding17,vertical: 0.0),
        decoration:BoxDecoration(
          color: MyColor.red_accent2,
          border: Border.all(color:MyColor.yellow3,width: MyString.padding02),
          borderRadius: BorderRadius.circular(MyString.padding12)
        ),
        child: textcustomColor(text:number,color:MyColor.white,size:MyString.padding16,isBold: true)
        // child: textcustomColor(text:'No.${index+1} | $number',color:MyColor.white,size:MyString.padding16,isBold: true)
      ),
    ],
  );
}
