part of 'settting_bloc.dart';

 class SettingEvent extends Equatable {
  @override
  List<Object?> get props => throw UnimplementedError();

}
 class SettingFetched extends SettingEvent{
  
 }