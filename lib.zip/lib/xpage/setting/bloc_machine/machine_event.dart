part of 'machine_bloc.dart';


 class ListMachineEvent extends Equatable {
  @override
  List<Object?> get props => throw UnimplementedError();

}
 class ListMachineFetched extends ListMachineEvent{}