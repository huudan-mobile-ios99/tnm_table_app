part of 'device_bloc.dart';

 class DeviceEvent extends Equatable {
  @override
  List<Object?> get props => throw UnimplementedError();

}
 class DeviceFetched extends DeviceEvent{}
